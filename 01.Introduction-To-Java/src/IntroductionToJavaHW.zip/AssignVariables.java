import java.util.Scanner;

/**
 * Created by Victoria Teneva on 13/10/2015.
 */
public class AssignVariables {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        byte b = 127;
        short sh = 32767;
        int i = 2000000000;
        long l = 919827112351L;
        char ch = 'c';
        boolean bool = false;
        float fl = 0.5f;
        double d = 0.1234567891011;
        String str = "Palo Alto, CA";

        System.out.println(b);
        System.out.println(ch);
    }
}
