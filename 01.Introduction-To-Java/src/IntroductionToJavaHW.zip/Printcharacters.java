/**
 * Created by Victoria Teneva on 13/10/2015.
 */
public class Printcharacters {
    public static void main(String[] args) {
        for (int i = 97; i < 123; i++) {
            System.out.println((char) i);
        }
    }
}
