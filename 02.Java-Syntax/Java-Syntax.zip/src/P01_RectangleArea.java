import java.util.Scanner;

/**
 * Created by Victoria Teneva on 16/10/2015.
 */
public class P01_RectangleArea {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int a = scan.nextInt();
        int b = scan.nextInt();

        System.out.println(a * b);
    }
}
